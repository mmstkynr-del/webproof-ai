import { Netmask } from 'netmask';
import { URL } from 'url';

const PRIVATE_RANGES = [
  '10.0.0.0/8',
  '172.16.0.0/12',
  '192.168.0.0/16',
  '127.0.0.0/8',
  '0.0.0.0/8',
  '169.254.0.0/16',
  '::1/128',
  'fc00::/7',
  'fe80::/10'
];

export function validateAndNormalizeUrl(inputUrl: string): string | null {
  try {
    const parsed = new URL(inputUrl);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return null;
    }
    
    const hostname = parsed.hostname.toLowerCase();
    
    // Localhost & internal domain checks
    if (hostname === 'localhost' || hostname.endsWith('.local') || hostname.endsWith('.internal')) {
      return null;
    }

    // IP address checks against private ranges
    for (const range of PRIVATE_RANGES) {
      try {
        const block = new Netmask(range);
        if (block.contains(hostname)) {
          return null;
        }
      } catch (e) {
        // Not an IP address, proceed
      }
    }

    // Normalize URL
    parsed.hash = ''; // Remove fragments
    return parsed.toString();
  } catch (err) {
    return null;
  }
}

export function isSameDomain(urlA: string, urlB: string): boolean {
  try {
    const domainA = new URL(urlA).hostname.replace(/^www\./, '');
    const domainB = new URL(urlB).hostname.replace(/^www\./, '');
    return domainA === domainB;
  } catch {
    return false;
  }
}
