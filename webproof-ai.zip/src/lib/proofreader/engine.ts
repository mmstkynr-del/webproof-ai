export interface Finding {
  category: 'SPELLING' | 'GRAMMAR' | 'PUNCTUATION' | 'CAPITALIZATION';
  incorrectText: string;
  suggestedCorrection: string;
  explanation: string;
  confidence: number;
}

const TURKISH_RULES = [
  {
    regex: /\bherkez\b/gi,
    category: 'SPELLING',
    correction: 'herkes',
    explanation: "Türkçe 'herkez' şeklinde bir kelime yoktur, doğrusu 'herkes'tir.",
    confidence: 98
  },
  {
    regex: /\byalnızca\b/gi,
    category: 'SPELLING',
    correction: 'yalnızca',
    explanation: "'Yalınızca' veya türevi yanlış yazımlarda doğrusu 'yalnızca'dır.",
    confidence: 90
  },
  {
    regex: /\byalnış\b/gi,
    category: 'SPELLING',
    correction: 'yanlış',
    explanation: "'Yalnış' kelimesinin doğru yazımı 'yanlış' şeklindedir (Yanılmaktan gelir).",
    confidence: 95
  },
  {
    regex: /\byalnız\b/gi,
    category: 'SPELLING',
    correction: 'yalnız',
    explanation: "'Yalınız' değil 'yalnız' yazılır (Yalından gelir).",
    confidence: 95
  },
  {
    regex: /\bşey de\b/gi,
    category: 'GRAMMAR',
    correction: 'şey de',
    explanation: "'Şey' kelimesi her zaman ayrı yazılır.",
    confidence: 95
  },
  {
    regex: /\bherşey\b/gi,
    category: 'SPELLING',
    correction: 'her şey',
    explanation: "'Her şey' kelimesi ayrı yazılır.",
    confidence: 98
  },
  {
    regex: /\bhiç bir\b/gi,
    category: 'SPELLING',
    correction: 'hiçbir',
    explanation: "'Hiçbir' bitişik yazılır.",
    confidence: 92
  },
  {
    regex: /\bşuan\b/gi,
    category: 'SPELLING',
    correction: 'şu an',
    explanation: "'Şu an' kelimesi ayrı yazılır.",
    confidence: 95
  },
  {
    regex: /\bdeğilmi\b/gi,
    category: 'GRAMMAR',
    correction: 'değil mi',
    explanation: "Soru eki 'mi/mı/mu/mü' ayrı yazılır.",
    confidence: 98
  },
  {
    regex: /\bgeliyormusunuz\b/gi,
    category: 'GRAMMAR',
    correction: 'geliyor musunuz',
    explanation: "Soru eki ve şahıs eki ayrı yazılır.",
    confidence: 98
  }
];

const ENGLISH_RULES = [
  {
    regex: /\bteh\b/gi,
    category: 'SPELLING',
    correction: 'the',
    explanation: "Common typo for 'the'.",
    confidence: 95
  },
  {
    regex: /\breceive\b/gi,
    category: 'SPELLING',
    correction: 'receive',
    explanation: "Remember: 'I' before 'E' except after 'C'.",
    confidence: 90
  },
  {
    regex: /\bi am agree\b/gi,
    category: 'GRAMMAR',
    correction: 'I agree',
    explanation: "'Agree' is a verb. Use 'I agree' instead of 'I am agree'.",
    confidence: 95
  },
  {
    regex: /\bshould of\b/gi,
    category: 'GRAMMAR',
    correction: 'should have',
    explanation: "Use 'should have' instead of 'should of'.",
    confidence: 98
  },
  {
    regex: /\btheir is\b/gi,
    category: 'GRAMMAR',
    correction: 'there is',
    explanation: "Use 'there is' for existence, 'their' indicates possession.",
    confidence: 88
  }
];

export function analyzeText(text: string, language: 'TR' | 'EN'): Finding[] {
  const findings: Finding[] = [];
  const rules = language === 'TR' ? TURKISH_RULES : ENGLISH_RULES;

  for (const rule of rules) {
    let match;
    while ((match = rule.regex.exec(text)) !== null) {
      // Ensure the exact matched text exists in source
      const matchedStr = match[0];
      
      findings.push({
        category: rule.category as any,
        incorrectText: matchedStr,
        suggestedCorrection: rule.correction,
        explanation: rule.explanation,
        confidence: rule.confidence
      });
    }
  }

  // Check repeated words (e.g. "ve ve", "the the")
  const repeatRegex = /\b(\w+)\s+\1\b/gi;
  let matchRepeat;
  while ((matchRepeat = repeatRegex.exec(text)) !== null) {
    const word = matchRepeat[1];
    if (word.length > 2) {
      findings.push({
        category: 'PUNCTUATION',
        incorrectText: `${word} ${word}`,
        suggestedCorrection: word,
        explanation: language === 'TR' 
          ? `'${word}' kelimesi üst üste iki kez tekrarlanmış.` 
          : `Duplicate word '${word}' detected.`,
        confidence: 92
      });
    }
  }

  return findings;
}
