import axios from 'axios';
import * as cheerio from 'cheerio';
import robotsParser from 'robots-parser';
import { validateAndNormalizeUrl, isSameDomain } from '../security';
import { extractArticleContent } from './extractor';
import { analyzeText } from '../proofreader/engine';

export interface CrawlTaskConfig {
  jobId: string;
  startUrl: string;
  maxPages: number;
  maxDepth: number;
  targetLang: string;
  onProgress?: (progress: any) => void;
}

export class WebCrawler {
  private visitedUrls = new Set<string>();
  private queue: { url: string; depth: number }[] = [];
  private robots: any = null;

  constructor(private config: CrawlTaskConfig) {}

  async initRobots(baseUrl: string) {
    try {
      const robotsUrl = new URL('/robots.txt', baseUrl).toString();
      const res = await axios.get(robotsUrl, { timeout: 3000, headers: { 'User-Agent': 'WebProofAI-Bot/1.0' } });
      this.robots = robotsParser(robotsUrl, res.data);
    } catch {
      this.robots = null;
    }
  }

  async run() {
    const normalizedStart = validateAndNormalizeUrl(this.config.startUrl);
    if (!normalizedStart) throw new Error("Invalid start URL or security violation.");

    await this.initRobots(normalizedStart);

    this.queue.push({ url: normalizedStart, depth: 0 });
    this.visitedUrls.add(normalizedStart);

    let pagesCrawled = 0;
    let pagesAnalyzed = 0;
    let errorsFound = 0;

    while (this.queue.length > 0 && pagesCrawled < this.config.maxPages) {
      const current = this.queue.shift();
      if (!current) break;

      if (this.robots && !this.robots.isAllowed(current.url, 'WebProofAI-Bot')) {
        continue;
      }

      try {
        const response = await axios.get(current.url, {
          timeout: 7000,
          headers: { 'User-Agent': 'WebProofAI-Bot/1.0 (Proofreading Crawler)' },
          maxResponseBytes: 5 * 1024 * 1024
        });

        pagesCrawled++;

        if (response.headers['content-type']?.includes('text/html')) {
          const html = response.data;
          const $ = cheerio.load(html);

          // Link Discovery
          if (current.depth < this.config.maxDepth) {
            $('a[href]').each((_, el) => {
              const href = $(el).attr('href');
              if (!href) return;

              try {
                const absoluteUrl = new URL(href, current.url).toString();
                const normalized = validateAndNormalizeUrl(absoluteUrl);

                if (normalized && isSameDomain(normalized, normalizedStart) && !this.visitedUrls.has(normalized)) {
                  this.visitedUrls.add(normalized);
                  this.queue.push({ url: normalized, depth: current.depth + 1 });
                }
              } catch {}
            });
          }

          // Content Extraction & Proofreading
          const extracted = extractArticleContent(html, current.url);
          if (extracted && extracted.textContent.length > 100) {
            pagesAnalyzed++;

            // Detect language (Simple heuristics or explicit setting)
            let lang: 'TR' | 'EN' = 'TR';
            if (this.config.targetLang === 'EN') lang = 'EN';
            else if (this.config.targetLang === 'AUTO') {
              const trCharCount = (extracted.textContent.match(/[ğüşıöçĞÜŞİÖÇ]/g) || []).length;
              lang = trCharCount > 3 ? 'TR' : 'EN';
            }

            const findings = analyzeText(extracted.textContent, lang);
            errorsFound += findings.length;

            // In production, sync with Prisma Database here
          }
        }
      } catch (err) {
        // Handle network or HTTP errors gracefully
      }
    }

    return {
      discovered: this.visitedUrls.size,
      crawled: pagesCrawled,
      analyzed: pagesAnalyzed,
      errors: errorsFound
    };
  }
}
