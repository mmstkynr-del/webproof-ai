import { JSDOM } from 'jsdom';
import { Readability } from '@mozilla/readability';

export interface ExtractedContent {
  title: string;
  textContent: string;
  cleanHtml: string;
}

export function extractArticleContent(html: string, url: string): ExtractedContent | null {
  try {
    const dom = new JSDOM(html, { url });
    const reader = new Readability(dom.window.document);
    const article = reader.parse();

    if (!article || !article.textContent.trim()) {
      return null;
    }

    return {
      title: article.title || dom.window.document.title || 'Untitled',
      textContent: article.textContent.replace(/\s+/g, ' ').trim(),
      cleanHtml: article.content || ''
    };
  } catch (error) {
    return null;
  }
}
