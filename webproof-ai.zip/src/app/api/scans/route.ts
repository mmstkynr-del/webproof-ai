import { NextRequest, NextResponse } from 'next/server';
import { validateAndNormalizeUrl } from '@/lib/security';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { url, language = 'AUTO', maxPages = 500, maxDepth = 10 } = body;

    const validUrl = validateAndNormalizeUrl(url);
    if (!validUrl) {
      return NextResponse.json({ error: 'Invalid URL or private IP address provided.' }, { status: 400 });
    }

    // Mock response for quick setup without mandatory DB connection during build
    const mockScanId = "scan-" + Date.now();

    return NextResponse.json({
      id: mockScanId,
      status: 'RUNNING',
      targetUrl: validUrl,
      language,
      maxPages,
      maxDepth,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error.' }, { status: 500 });
  }
}
