import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  return NextResponse.json({
    id: params.id,
    status: 'RUNNING',
    pagesDiscovered: 142,
    pagesCrawled: 89,
    pagesAnalyzed: 82,
    errorsFound: 14,
    progress: 62
  });
}
