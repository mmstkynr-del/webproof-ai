import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const mockFindings = [
    {
      id: "f-1",
      url: "https://example.com/haber/101",
      pageTitle: "Gelişen Teknoloji ve Yapay Zeka Trendleri",
      language: "TR",
      category: "SPELLING",
      incorrectText: "herkez",
      suggestedCorrection: "herkes",
      explanation: "Türkçe 'herkez' şeklinde bir kelime yoktur, doğrusu 'herkes'tir.",
      confidence: 98,
      createdAt: new Date().toISOString()
    },
    {
      id: "f-2",
      url: "https://example.com/haber/101",
      pageTitle: "Gelişen Teknoloji ve Yapay Zeka Trendleri",
      language: "TR",
      category: "SPELLING",
      incorrectText: "herşey",
      suggestedCorrection: "her şey",
      explanation: "'Her şey' kelimesi ayrı yazılır.",
      confidence: 98,
      createdAt: new Date().toISOString()
    },
    {
      id: "f-3",
      url: "https://example.com/news/tech-future",
      pageTitle: "Future of AI in Everyday Life",
      language: "EN",
      category: "GRAMMAR",
      incorrectText: "i am agree",
      suggestedCorrection: "I agree",
      explanation: "'Agree' is a verb. Use 'I agree' instead of 'I am agree'.",
      confidence: 95,
      createdAt: new Date().toISOString()
    }
  ];

  return NextResponse.json({ findings: mockFindings });
}
