import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'WebProof AI - Professional Proofreading Crawler',
  description: 'Automated Turkish & English spelling and grammar analysis for entire websites.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="tr">
      <body>{children}</body>
    </html>
  );
}
