'use client';

import React, { useState } from 'react';
import { Search, Globe, Shield, Activity, FileText, CheckCircle2, AlertTriangle, ArrowRight, Download } from 'lucide-react';

export default function Home() {
  const [url, setUrl] = useState('');
  const [language, setLanguage] = useState('AUTO');
  const [uiLang, setUiLang] = useState<'TR' | 'EN'>('TR');
  const [isScanning, setIsScanning] = useState(false);
  const [scanData, setScanData] = useState<any>(null);
  const [findings, setFindings] = useState<any[]>([]);

  const handleStartScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;

    setIsScanning(true);
    setScanData({
      pagesDiscovered: 45,
      pagesCrawled: 28,
      pagesAnalyzed: 24,
      errorsFound: 3
    });

    setTimeout(() => {
      setIsScanning(false);
      setFindings([
        {
          id: '1',
          url: url,
          title: 'Ana Sayfa ve İletişim',
          language: 'TR',
          category: 'SPELLING',
          incorrect: 'herkez',
          correction: 'herkes',
          explanation: 'Türkçe "herkez" kelimesi yanlış yazılmıştır. Doğrusu "herkes" olmalıdır.',
          confidence: 98
        },
        {
          id: '2',
          url: url,
          title: 'Hakkımızda Detayları',
          language: 'TR',
          category: 'SPELLING',
          incorrect: 'herşey',
          correction: 'her şey',
          explanation: '"Her şey" ayrı yazılır.',
          confidence: 95
        }
      ]);
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Shield className="w-8 h-8 text-sky-400" />
            <span className="text-xl font-bold tracking-tight text-white">WebProof <span className="text-sky-400">AI</span></span>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => setUiLang(uiLang === 'TR' ? 'EN' : 'TR')}
              className="px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800 text-sm font-medium hover:bg-slate-700 transition"
            >
              🌐 {uiLang === 'TR' ? 'TR | EN' : 'EN | TR'}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
            {uiLang === 'TR' ? 'Web Sitenizdeki Dil ve Yazım Hatalarını Yakalayın' : 'Detect Spelling & Grammar Errors Across Websites'}
          </h1>
          <p className="text-lg text-slate-400">
            {uiLang === 'TR' 
              ? 'Tüm siteyi tarayan, Türkçe ve İngilizce imla ve gramer hatalarını tespit eden profesyonel denetleme altyapısı.'
              : 'Deeply crawl any site, analyze content, and uncover proofreading mistakes in Turkish & English.'}
          </p>
        </div>

        {/* Scan Input Box */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-12 shadow-2xl max-w-4xl mx-auto">
          <form onSubmit={handleStartScan} className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Globe className="absolute left-4 top-3.5 w-5 h-5 text-slate-500" />
                <input 
                  type="url" 
                  required
                  placeholder="https://www.bbc.com/turkce"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-12 pr-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 transition"
                />
              </div>
              <select 
                value={language} 
                onChange={(e) => setLanguage(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-slate-300 focus:outline-none focus:border-sky-500 transition"
              >
                <option value="AUTO">{uiLang === 'TR' ? 'Otomatik Dil' : 'Auto Detect'}</option>
                <option value="TR">Türkçe</option>
                <option value="EN">English</option>
              </select>
              <button 
                type="submit" 
                disabled={isScanning}
                className="bg-sky-500 hover:bg-sky-600 disabled:bg-sky-800 text-white font-semibold px-6 py-3 rounded-xl flex items-center justify-center space-x-2 transition"
              >
                {isScanning ? (
                  <span>{uiLang === 'TR' ? 'Taranıyor...' : 'Scanning...'}</span>
                ) : (
                  <>
                    <span>{uiLang === 'TR' ? 'Siteyi Tara' : 'Scan Website'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Real-time Progress Bar */}
        {isScanning && (
          <div className="max-w-4xl mx-auto bg-slate-900 border border-slate-800 rounded-xl p-6 mb-12">
            <div className="flex justify-between items-center mb-3">
              <span className="text-sm font-medium text-sky-400 flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" /> {uiLang === 'TR' ? 'Tarama Devam Ediyor...' : 'Crawling Site...'}
              </span>
              <span className="text-sm text-slate-400">62%</span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-3 overflow-hidden mb-6">
              <div className="bg-sky-500 h-3 rounded-full w-[62%] transition-all duration-500"></div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-xs text-slate-400">{uiLang === 'TR' ? 'Kesfedilen' : 'Discovered'}</div>
                <div className="text-lg font-bold text-white">{scanData?.pagesDiscovered}</div>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-xs text-slate-400">{uiLang === 'TR' ? 'Taranan' : 'Crawled'}</div>
                <div className="text-lg font-bold text-white">{scanData?.pagesCrawled}</div>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-xs text-slate-400">{uiLang === 'TR' ? 'Analiz Edilen' : 'Analyzed'}</div>
                <div className="text-lg font-bold text-white">{scanData?.pagesAnalyzed}</div>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-xs text-slate-400">{uiLang === 'TR' ? 'Hata Bulunan' : 'Errors'}</div>
                <div className="text-lg font-bold text-amber-400">{scanData?.errorsFound}</div>
              </div>
            </div>
          </div>
        )}

        {/* Results Dashboard */}
        {findings.length > 0 && (
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <FileText className="w-6 h-6 text-sky-400" /> {uiLang === 'TR' ? 'Tespit Edilen Dil Hataları' : 'Proofreading Findings'}
              </h2>
              <button className="flex items-center space-x-2 bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg text-sm font-medium transition">
                <Download className="w-4 h-4" />
                <span>Export JSON / CSV</span>
              </button>
            </div>

            <div className="space-y-4">
              {findings.map((item) => (
                <div key={item.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition space-y-3">
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <span className="inline-block px-2.5 py-0.5 rounded text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 mb-2">
                        {item.category}
                      </span>
                      <h3 className="font-semibold text-white">{item.title}</h3>
                      <a href={item.url} target="_blank" rel="noreferrer" className="text-xs text-slate-400 hover:text-sky-400 underline">
                        {item.url}
                      </a>
                    </div>
                    <span className="text-xs font-bold px-2.5 py-1 rounded bg-slate-800 text-sky-400 border border-slate-700">
                      %{item.confidence} {uiLang === 'TR' ? 'Güven' : 'Confidence'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-950 p-3.5 rounded-lg border border-slate-800 text-sm">
                    <div>
                      <span className="text-xs text-rose-400 block mb-1 font-medium">{uiLang === 'TR' ? 'Hatalı Metin:' : 'Incorrect:'}</span>
                      <code className="text-rose-300 bg-rose-950/40 px-2 py-1 rounded border border-rose-900/50">{item.incorrect}</code>
                    </div>
                    <div>
                      <span className="text-xs text-emerald-400 block mb-1 font-medium">{uiLang === 'TR' ? 'Önerilen Düzeltme:' : 'Suggested Correction:'}</span>
                      <code className="text-emerald-300 bg-emerald-950/40 px-2 py-1 rounded border border-emerald-900/50">{item.correction}</code>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400">{item.explanation}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
